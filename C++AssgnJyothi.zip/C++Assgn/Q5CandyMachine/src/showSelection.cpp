#include "CashRegister.h"
#include "DispenserType.h"

void showSelection(void)
{
	cout << "************CANDY MACHINE************" << endl;
	cout << "select your favourite item" << endl;
	cout << "1. CANDY" << endl;
	cout << "2. CHIPS" << endl;
	cout << "3. GUM" << endl;
	cout << "4. COOKIES" << endl;
	cout << "5. exit" << endl;
}
