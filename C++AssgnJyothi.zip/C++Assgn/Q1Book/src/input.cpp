#include "Book.h"

void Book :: input(void)
{
	cout << "enter the book no. :";
	cin >> bookNo;

	cout << "enter the book title:";
	cin >> bookTitle;
	
	cout << "enter the price:";
	cin >> price;
}
