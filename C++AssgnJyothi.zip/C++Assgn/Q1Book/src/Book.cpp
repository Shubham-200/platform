#include "Book.h"

int main(void)
{
	Book b1;

	b1.input();
	b1.purchase();

	return EXIT_SUCCESS;
}
